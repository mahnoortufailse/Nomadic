//@ts-nocheck
"use client"

import type React from "react"

import { useState, useEffect, useCallback, useRef } from "react"
import toast from 'react-hot-toast'

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { MapPin, Users, Plus, Minus, Check, X, Loader2, Star, Camera, Calendar, Shield } from "lucide-react"
import { cn } from "@/lib/utils"
import Link from "next/link"
import Image from "next/image"
import { calculateBookingPrice, fetchPricingSettings } from "@/lib/pricing"
import type { BookingFormData, Settings } from "@/lib/types"

export default function BookingPage() {
  const [guestCount, setGuestCount] = useState(2)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [settings, setSettings] = useState<Settings | null>(null)
  const [loadingSettings, setLoadingSettings] = useState(true)
  const isUserInteracting = useRef(false)
  const refreshTimeoutRef = useRef<NodeJS.Timeout>()
  const interactionTimeoutRef = useRef<NodeJS.Timeout>()
  const isRefreshing = useRef(false)

  const [formData, setFormData] = useState<BookingFormData>({
    customerName: "",
    customerEmail: "",
    customerPhone: "+971",
    bookingDate: "",
    location: "Desert",
    numberOfTents: 1,
    addOns: {
      charcoal: false,
      firewood: false,
      portableToilet: false,
    },
    hasChildren: false,
    notes: "",
  })

  const [selectedCustomAddOns, setSelectedCustomAddOns] = useState<string[]>([])
  const [selectedDate, setSelectedDate] = useState<Date>()
  const [pricing, setPricing] = useState(calculateBookingPrice(1, "Desert", formData.addOns, false))
  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [touched, setTouched] = useState<Record<string, boolean>>({})

  const campingImages = [
    {
      src: "/desert-camping-with-tents-under-starry-sky.jpg",
      alt: "Desert camping with tents under starry sky",
    },
    {
      src: "/desert-landscape-with-sand-dunes-and-warm-golden-l.jpg",
      alt: "Desert landscape with sand dunes",
    },
    {
      src: "/wadi-valley-camping-with-water-pools-and-palm-tree.jpg",
      alt: "Wadi valley camping with water pools",
    },
    {
      src: "/mountain-camping-with-rocky-peaks-and-tents.jpg",
      alt: "Mountain camping with rocky peaks",
    },
    {
      src: "/desert-landscape-with-sand-dunes-and-warm-golden-l.jpg",
      alt: "Private event camping setup",
    },
  ]

  useEffect(() => {
    const loadSettings = async () => {
      if (isRefreshing.current) return

      try {
        setLoadingSettings(true)
        isRefreshing.current = true
        const settingsData = await fetchPricingSettings()
        setSettings(settingsData)
      } catch (error) {
        console.error("Failed to load settings:", error)
      } finally {
        setLoadingSettings(false)
        isRefreshing.current = false
      }
    }
    loadSettings()
  }, [])

  const refreshSettings = useCallback(async () => {
    if (!isUserInteracting.current && !isRefreshing.current) {
      console.log("[v0] Refreshing settings - user not interacting")
      try {
        isRefreshing.current = true
        const settingsData = await fetchPricingSettings()
        setSettings(settingsData)
      } catch (error) {
        console.error("Failed to refresh settings:", error)
      } finally {
        isRefreshing.current = false
      }
    } else {
      console.log("[v0] Skipping refresh - user is interacting or already refreshing")
    }
  }, [])

  useEffect(() => {
    if (refreshTimeoutRef.current) {
      clearTimeout(refreshTimeoutRef.current)
    }

    const scheduleRefresh = () => {
      refreshTimeoutRef.current = setTimeout(() => {
        refreshSettings()
        scheduleRefresh()
      }, 30000)
    }

    scheduleRefresh()

    return () => {
      if (refreshTimeoutRef.current) {
        clearTimeout(refreshTimeoutRef.current)
      }
    }
  }, [refreshSettings])

  const minDate = new Date()
  minDate.setDate(minDate.getDate() + 2)

  useEffect(() => {
    if (!settings) return

    const customAddOnsWithSelection = (settings.customAddOns || []).map((addon) => ({
      ...addon,
      selected: selectedCustomAddOns.includes(addon.id),
    }))

    const newPricing = calculateBookingPrice(
      formData.numberOfTents,
      formData.location,
      formData.addOns,
      formData.hasChildren,
      customAddOnsWithSelection,
      settings,
    )
    setPricing(newPricing)
  }, [formData.numberOfTents, formData.location, formData.addOns, formData.hasChildren, selectedCustomAddOns, settings])

  const setUserInteracting = useCallback((interacting: boolean, duration = 5000) => {
    console.log(`[v0] Setting user interaction: ${interacting}`)
    isUserInteracting.current = interacting

    if (interactionTimeoutRef.current) {
      clearTimeout(interactionTimeoutRef.current)
    }

    if (interacting) {
      interactionTimeoutRef.current = setTimeout(() => {
        console.log("[v0] User interaction timeout - setting to false")
        isUserInteracting.current = false
      }, duration)
    }
  }, [])

  const handleDateSelect = (date: Date | undefined) => {
    setUserInteracting(true)
    setSelectedDate(date)
    setFormData((prev) => ({
      ...prev,
      bookingDate: date ? date.toISOString().split("T")[0] : "",
    }))
    setTouched((prev) => ({ ...prev, bookingDate: true }))

    if (date) {
      const newErrors = { ...errors }
      delete newErrors.bookingDate
      setErrors(newErrors)
    }
  }

  const handleTentChange = (increment: boolean) => {
    setUserInteracting(true)
    const newCount = increment ? formData.numberOfTents + 1 : formData.numberOfTents - 1
    if (newCount >= 1 && newCount <= 5) {
      setFormData((prev) => ({ ...prev, numberOfTents: newCount }))
      setTouched((prev) => ({ ...prev, numberOfTents: true }))

      if (formData.location === "Wadi") {
        const newErrors = { ...errors }
        if (newCount < 2) {
          newErrors.numberOfTents = "Wadi location requires at least 2 tents"
        } else {
          delete newErrors.numberOfTents
        }
        setErrors(newErrors)
      }
    }
  }

  const handleGuestChange = (increment: boolean) => {
    setUserInteracting(true, 3000) // Shorter timeout for guest count
    const newCount = increment ? guestCount + 1 : guestCount - 1
    if (newCount >= 1 && newCount <= 20) {
      setGuestCount(newCount)
    }
  }

  const handleInputChange = (field: keyof BookingFormData, value: string | boolean) => {
    setUserInteracting(true)
    setFormData((prev) => ({ ...prev, [field]: value }))
    setTouched((prev) => ({ ...prev, [field]: true }))

    if (typeof value === "string") {
      validateField(field, value)
    }
  }

  const handleAddOnChange = (addOn: keyof typeof formData.addOns, checked: boolean) => {
    setUserInteracting(true)
    setFormData((prev) => ({
      ...prev,
      addOns: { ...prev.addOns, [addOn]: checked },
    }))
  }

  const handleCustomAddOnChange = (addOnId: string, checked: boolean) => {
    setUserInteracting(true)
    setSelectedCustomAddOns((prev) => (checked ? [...prev, addOnId] : prev.filter((id) => id !== addOnId)))
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.customerName.trim()) newErrors.customerName = "Name is required"
    if (!formData.customerEmail.trim()) {
      newErrors.customerEmail = "Email is required"
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.customerEmail)) {
      newErrors.customerEmail = "Please enter a valid email address"
    }

    if (!formData.customerPhone.startsWith("+971") || formData.customerPhone.length < 12) {
      newErrors.customerPhone = "Valid UAE phone number required (+971501234567)"
    }
    if (!formData.bookingDate) newErrors.bookingDate = "Booking date is required"
    if (formData.location === "Wadi" && formData.numberOfTents < 2) {
      newErrors.numberOfTents = "Wadi location requires at least 2 tents"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const validateField = (field: string, value: string) => {
    const newErrors = { ...errors }

    switch (field) {
      case "customerName":
        if (!value.trim()) {
          newErrors.customerName = "Name is required"
        } else {
          delete newErrors.customerName
        }
        break
      case "customerEmail":
        if (!value.trim()) {
          newErrors.customerEmail = "Email is required"
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          newErrors.customerEmail = "Please enter a valid email address"
        } else {
          delete newErrors.customerEmail
        }
        break
      case "customerPhone":
        if (!value.startsWith("+971") || value.length < 12) {
          newErrors.customerPhone = "Valid UAE phone number required (+971501234567)"
        } else {
          delete newErrors.customerPhone
        }
        break
      case "bookingDate":
        if (!value) {
          newErrors.bookingDate = "Booking date is required"
        } else {
          delete newErrors.bookingDate
        }
        break
      case "numberOfTents":
        if (formData.location === "Wadi" && formData.numberOfTents < 2) {
          newErrors.numberOfTents = "Wadi location requires at least 2 tents"
        } else {
          delete newErrors.numberOfTents
        }
        break
    }

    setErrors(newErrors)
  }

  const handleBlur = (field: string, value: string) => {
    setTouched((prev) => ({ ...prev, [field]: true }))
    validateField(field, value)
    setUserInteracting(true, 2000)
  }

 const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const allTouched = {
      customerName: true,
      customerEmail: true,
      customerPhone: true,
      bookingDate: true,
      numberOfTents: true,
    }
    setTouched(allTouched)

    if (!validateForm()) {
      const firstError = Object.keys(errors)[0]
      if (firstError) {
        const element = document.getElementById(firstError)
        if (element) {
          element.scrollIntoView({ behavior: "smooth", block: "center" })
        }
      }
      
      // Show error toast for form validation
      toast.error("Check all required fields and try again.")
      
      return
    }

    if (formData.numberOfTents > 5) {
      // Show info toast for large booking
      toast.info("For bookings with more than 5 tents, please contact us directly for a custom quote.")
      return
    }

    setIsLoading(true)
    
    // Show loading toast
    const loadingToast = toast.loading("Processing your booking...")

    try {
      const bookingData = {
        ...formData,
        selectedCustomAddOns,
      }

      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bookingData),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Failed to create booking")
      }

      const { bookingId } = await response.json()

      const checkoutResponse = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bookingId,
          ...formData,
          selectedCustomAddOns,
          pricing,
        }),
      })

      if (!checkoutResponse.ok) {
        throw new Error("Failed to create checkout session")
      }

      const { url } = await checkoutResponse.json()
      
      // Dismiss loading toast and show success
      toast.dismiss(loadingToast)
      toast.success("Booking created successfully!")
      
      // Add a small delay to show the success message
      setTimeout(() => {
        window.location.href = url
      }, 1500)
      
    } catch (error) {
      console.error("Booking error:", error)
      
      // Dismiss loading toast and show error
      toast.dismiss(loadingToast)
      toast.error("Booking failed")
    } finally {
      setIsLoading(false)
    }
  }

  const handleManualRefresh = async () => {
    console.log("[v0] Manual refresh triggered")
    isUserInteracting.current = false
    await refreshSettings()
  }

  useEffect(() => {
    return () => {
      if (interactionTimeoutRef.current) {
        clearTimeout(interactionTimeoutRef.current)
      }
    }
  }, [])

  if (loadingSettings) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#FBF9D9] via-[#E6CFA9] to-[#D3B88C] flex items-center justify-center">
        <div className="text-center animate-fade-in-up">
          <div className="relative">
            <Loader2 className="w-12 h-12 animate-spin text-[#3C2317] mx-auto mb-6" />
            <div className="absolute inset-0 w-12 h-12 border-4 border-[#3C2317]/20 rounded-full animate-pulse mx-auto"></div>
          </div>
          <p className="text-[#3C2317] text-lg font-medium">Loading your premium camping experience...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#FBF9D9] via-[#E6CFA9] to-[#D3B88C]">
      <nav className="bg-[#3C2317]/90 backdrop-blur-md border-b border-[#3C2317]/50 shadow-lg sticky top-0 z-50 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4 group">
              <div className="relative">
                <div className="w-12 h-12 bg-gradient-to-br from-[#3C2317] to-[#5D4037] rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-105">
                  <MapPin className="w-6 h-6 text-[#FBF9D9]" />
                </div>
                <div className="absolute -inset-1 bg-gradient-to-br from-[#3C2317]/20 to-[#5D4037]/20 rounded-xl blur opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              <div>
                <span className="text-3xl font-bold tracking-wide text-white">NOMADIC</span>
                <p className="text-sm text-white/80">Premium Desert Experiences</p>
              </div>
            </Link>
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1 text-[#D3B88C]">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <span className="text-sm text-white/80">Luxury Certified</span>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-12 animate-fade-in-up">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
            <div className="lg:col-span-3">
              <div className="relative h-[500px] rounded-2xl overflow-hidden shadow-2xl group">
                <Image
                  src={
                    campingImages[currentImageIndex].src ||
                    "/placeholder.svg?height=500&width=800&query=luxury desert camping"
                  }
                  alt={campingImages[currentImageIndex].alt}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#3C2317]/40 via-transparent to-transparent"></div>
               
                <div className="absolute bottom-6 left-6 text-[#FBF9D9]">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="flex space-x-1">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current text-[#D3B88C]" />
                      ))}
                    </div>
                    <span className="text-sm font-medium">Premium Experience</span>
                  </div>
                  <p className="text-sm opacity-90">{campingImages[currentImageIndex].alt}</p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-1 gap-4">
              {campingImages.slice(1, 5).map((image, index) => (
                <div
                  key={index}
                  className="relative h-[115px] lg:h-[115px] rounded-xl overflow-hidden shadow-lg cursor-pointer group transition-all duration-300 hover:shadow-xl hover:scale-105"
                  onClick={() => setCurrentImageIndex(index + 1)}
                >
                  <Image
                    src={image.src || "/placeholder.svg?height=115&width=200&query=camping scene"}
                    alt={image.alt}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-[#3C2317]/20 group-hover:bg-[#3C2317]/10 transition-colors duration-300"></div>
                  {currentImageIndex === index + 1 && (
                    <div className="absolute inset-0 border-3 border-[#D3B88C] rounded-xl"></div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="text-center lg:text-left mb-8">
            <h1 className="text-4xl lg:text-5xl font-bold text-[#3C2317] mb-4 text-balance">
              Nomadic <span className="text-[#D3B88C]">Premium</span> Camping
            </h1>
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 mb-4 lg:mb-0">
                <div className="flex items-center space-x-2 text-[#3C2317]/80">
                  <MapPin className="w-5 h-5 text-[#D3B88C]" />
                  <span className="font-medium">Desert • Wadi • Mountain</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current text-[#D3B88C]" />
                    ))}
                  </div>
                  <span className="text-[#3C2317]/80 font-medium">Luxury Certified</span>
                </div>
                <div className="flex items-center space-x-2 text-[#3C2317]/80">
                  <Shield className="w-5 h-5 text-[#D3B88C]" />
                  <span className="font-medium">Private & Secure</span>
                </div>
              </div>
            </div>
            <p className="text-lg text-[#3C2317]/80 max-w-2xl text-pretty">
              Experience the UAE's most luxurious camping adventure with premium amenities, breathtaking locations, and
              unforgettable memories under the stars.
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <Card className="border-[#D3B88C]/50 shadow-xl hover:shadow-2xl transition-all duration-300 animate-scale-in bg-[#FBF9D9]/80 backdrop-blur-sm !py-0">
              <CardHeader className="bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 border-b border-[#D3B88C]/50 h-14 py-4">
                <CardTitle className="text-[#3C2317] flex items-center space-x-3 text-xl ">
                  <Users className="w-6 h-6 text-[#3C2317] " />
                  <span>Who's joining the adventure?</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                <p className="text-[#3C2317]/80 mb-6 leading-relaxed">
                  Each luxury tent accommodates up to 4 guests comfortably. Let us know your group size so we can create
                  the perfect setup for your desert experience.
                </p>
                <div className="flex items-center justify-center space-x-6">
                  <Button
                    type="button"
                    variant="outline"
                    size="lg"
                    onClick={() => handleGuestChange(false)}
                    disabled={guestCount <= 1}
                    className="border-2 border-[#D3B88C] hover:border-[#3C2317] hover:bg-[#3C2317]/5 transition-all duration-300 h-12 w-12 rounded-xl"
                  >
                    <Minus className="h-5 w-5" />
                  </Button>
                  <div className="flex items-center space-x-4 px-8 py-4 bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 rounded-2xl border border-[#D3B88C]/30">
                    <Users className="h-6 w-6 text-[#3C2317]" />
                    <span className="text-2xl font-bold text-[#3C2317]">{guestCount}</span>
                    <span className="text-[#3C2317]/80 font-medium">guest{guestCount !== 1 ? "s" : ""}</span>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="lg"
                    onClick={() => handleGuestChange(true)}
                    disabled={guestCount >= 20}
                    className="border-2 border-[#D3B88C] hover:border-[#3C2317] hover:bg-[#3C2317]/5 transition-all duration-300 h-12 w-12 rounded-xl"
                  >
                    <Plus className="h-5 w-5" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-[#D3B88C]/50 shadow-xl hover:shadow-2xl transition-all duration-300 bg-[#FBF9D9]/80 backdrop-blur-sm !py-0">
              <CardHeader className="bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 border-b border-[#D3B88C]/50 h-14 py-4">
                <CardTitle className="text-[#3C2317] flex items-center space-x-3 text-xl">
                  <Calendar className="w-6 h-6 text-[#3C2317]" />
                  <span>Choose your perfect date</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-8">
                <div className="mb-4">
                  <Label htmlFor="bookingDate" className="text-[#3C2317] font-medium mb-3 block">
                    Select Date *
                  </Label>
                </div>

                <Input
                  id="bookingDate"
                  type="date"
                  value={formData.bookingDate}
                  onChange={(e) => {
                    handleInputChange("bookingDate", e.target.value)
                    if (e.target.value) {
                      setSelectedDate(new Date(e.target.value))
                    }
                  }}
                  onBlur={(e) => handleBlur("bookingDate", e.target.value)}
                  min={minDate.toISOString().split("T")[0]}
                  className={cn(
                    "border-2 border-[#D3B88C] focus:border-[#3C2317] focus:ring-2 focus:ring-[#3C2317]/20 transition-all duration-300 h-14 rounded-xl",
                    errors.bookingDate && touched.bookingDate && "border-red-500 focus:border-red-500",
                  )}
                />

                {errors.bookingDate && touched.bookingDate && (
                  <p className="text-sm text-red-600 mt-3 flex items-center space-x-2">
                    <X className="w-4 h-4" />
                    <span>{errors.bookingDate}</span>
                  </p>
                )}
                <p className="text-sm text-[#3C2317]/80 mt-4 flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-[#3C2317]" />
                  <span>Minimum 2 days advance booking required for premium preparation</span>
                </p>
              </CardContent>
            </Card>

            <form className="space-y-8">
              <Card className="border-[#D3B88C]/50 shadow-xl hover:shadow-2xl transition-all duration-300 bg-[#FBF9D9]/80 backdrop-blur-sm !py-0">
                <CardHeader className="bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 border-b border-[#D3B88C]/50 h-14 py-4">
                  <CardTitle className="text-[#3C2317] text-xl">Personal Information</CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-8">
                  <div>
                    <Label htmlFor="customerName" className="text-[#3C2317] mb-3 block font-medium">
                      Full Name *
                    </Label>
                    <Input
                      id="customerName"
                      value={formData.customerName}
                      onChange={(e) => handleInputChange("customerName", e.target.value)}
                      onBlur={(e) => handleBlur("customerName", e.target.value)}
                      className={cn(
                        "border-2 border-[#D3B88C] focus:border-[#3C2317] focus:ring-2 focus:ring-[#3C2317]/20 transition-all duration-300 h-14 rounded-xl",
                        errors.customerName && touched.customerName && "border-red-500 focus:border-red-500",
                      )}
                      placeholder="Enter your full name"
                    />
                    {errors.customerName && touched.customerName && (
                      <p className="text-sm text-red-600 mt-2 flex items-center space-x-2">
                        <X className="w-4 h-4" />
                        <span>{errors.customerName}</span>
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="customerEmail" className="text-[#3C2317] mb-3 block font-medium">
                      Email Address *
                    </Label>
                    <Input
                      id="customerEmail"
                      type="email"
                      value={formData.customerEmail}
                      onChange={(e) => handleInputChange("customerEmail", e.target.value)}
                      onBlur={(e) => handleBlur("customerEmail", e.target.value)}
                      className={cn(
                        "border-2 border-[#D3B88C] focus:border-[#3C2317] focus:ring-2 focus:ring-[#3C2317]/20 transition-all duration-300 h-14 rounded-xl",
                        errors.customerEmail && touched.customerEmail && "border-red-500 focus:border-red-500",
                      )}
                      placeholder="your.email@example.com"
                    />
                    {errors.customerEmail && touched.customerEmail && (
                      <p className="text-sm text-red-600 mt-2 flex items-center space-x-2">
                        <X className="w-4 h-4" />
                        <span>{errors.customerEmail}</span>
                      </p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="customerPhone" className="text-[#3C2317] mb-3 block font-medium">
                      Phone Number *
                    </Label>
                    <Input
                      id="customerPhone"
                      value={formData.customerPhone}
                      onChange={(e) => handleInputChange("customerPhone", e.target.value)}
                      onBlur={(e) => handleBlur("customerPhone", e.target.value)}
                      placeholder="+971501234567"
                      className={cn(
                        "border-2 border-[#D3B88C] focus:border-[#3C2317] focus:ring-2 focus:ring-[#3C2317]/20 transition-all duration-300 h-14 rounded-xl",
                        errors.customerPhone && touched.customerPhone && "border-red-500 focus:border-red-500",
                      )}
                    />
                    {errors.customerPhone && touched.customerPhone && (
                      <p className="text-sm text-red-600 mt-2 flex items-center space-x-2">
                        <X className="w-4 h-4" />
                        <span>{errors.customerPhone}</span>
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-[#D3B88C]/50 shadow-xl hover:shadow-2xl transition-all duration-300 bg-[#FBF9D9]/80 backdrop-blur-sm !py-0">
                <CardHeader className="bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 border-b border-[#D3B88C]/50 h-14 py-4">
                  <CardTitle className="text-[#3C2317] text-xl">Booking Details</CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-8">
                  <div>
                    <Label className="text-[#3C2317] mb-3 block font-medium">Location *</Label>
                    <Select
                      value={formData.location}
                      onValueChange={(value: "Desert" | "Mountain" | "Wadi") => {
                        handleInputChange("location", value)
                        validateField("numberOfTents", formData.numberOfTents.toString())
                      }}
                    >
                      <SelectTrigger className="border-2 border-[#D3B88C] focus:border-[#3C2317] focus:ring-2 focus:ring-[#3C2317]/20 transition-all duration-300 h-14 rounded-xl">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Desert">🏜️ Desert - Classic dune experience</SelectItem>
                        <SelectItem value="Mountain">⛰️ Mountain - Elevated adventure</SelectItem>
                        <SelectItem value="Wadi">🌊 Wadi - Oasis experience (min. 2 tents)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-[#3C2317] mb-3 block font-medium">Number of Tents *</Label>
                    <div className="flex items-center justify-center space-x-6">
                      <Button
                        type="button"
                        variant="outline"
                        size="lg"
                        onClick={() => handleTentChange(false)}
                        disabled={formData.numberOfTents <= 1}
                        className="border-2 border-[#D3B88C] hover:border-[#3C2317] hover:bg-[#3C2317]/5 transition-all duration-300 h-12 w-12 rounded-xl"
                      >
                        <Minus className="h-5 w-5" />
                      </Button>
                      <div className="flex items-center space-x-4 px-8 py-4 bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 rounded-2xl border border-[#D3B88C]/30">
                        <Users className="h-6 w-6 text-[#3C2317]" />
                        <span className="text-2xl font-bold text-[#3C2317]">{formData.numberOfTents}</span>
                        <span className="text-[#3C2317]/80 font-medium">
                          tent{formData.numberOfTents !== 1 ? "s" : ""}
                        </span>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="lg"
                        onClick={() => handleTentChange(true)}
                        disabled={formData.numberOfTents >= 5}
                        className="border-2 border-[#D3B88C] hover:border-[#3C2317] hover:bg-[#3C2317]/5 transition-all duration-300 h-12 w-12 rounded-xl"
                      >
                        <Plus className="h-5 w-5" />
                      </Button>
                    </div>
                    {errors.numberOfTents && touched.numberOfTents && (
                      <p className="text-sm text-red-600 mt-3 flex items-center justify-center space-x-2">
                        <X className="w-4 h-4" />
                        <span>{errors.numberOfTents}</span>
                      </p>
                    )}
                    {formData.numberOfTents >= 5 && (
                      <p className="text-sm text-[#3C2317]/80 mt-3 text-center">
                        For more than 5 tents, please contact us directly
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

            <Card className="border-[#D3B88C]/50 shadow-xl hover:shadow-2xl transition-all duration-300 bg-[#FBF9D9]/80 backdrop-blur-sm !py-0">
  <CardHeader className="bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 border-b border-[#D3B88C]/50 h-14 py-4">
    <CardTitle className="text-[#3C2317] text-xl">Premium Add-ons</CardTitle>
  </CardHeader>
  <CardContent className="p-6 space-y-3">
    <div className="grid gap-1">
      {/* Charcoal Add-on */}
      <div className="flex items-start space-x-4 p-4 rounded-xl hover:bg-[#E6CFA9]/50 transition-all duration-300 border border-transparent hover:border-[#D3B88C]/30">
        <Checkbox
          id="charcoal"
          checked={formData.addOns.charcoal}
          onCheckedChange={(checked) => handleAddOnChange("charcoal", checked as boolean)}
          className="border-2 border-[#3C2317] data-[state=checked]:bg-[#3C2317] data-[state=checked]:border-[#3C2317] h-5 w-5 mt-1 flex-shrink-0"
        />
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start mb-1">
            <Label htmlFor="charcoal" className="text-[#3C2317] font-medium text-base cursor-pointer">
              Premium Charcoal
            </Label>
            <span className="text-[#3C2317] font-bold text-base whitespace-nowrap ml-3">
              AED {settings?.addOnPrices?.charcoal || 60}
            </span>
          </div>
          <p className="text-sm text-[#3C2317]/80 mt-1">High-quality charcoal for perfect grilling</p>
        </div>
      </div>

      {/* Firewood Add-on */}
      <div className="flex items-start space-x-4 p-4 rounded-xl hover:bg-[#E6CFA9]/50 transition-all duration-300 border border-transparent hover:border-[#D3B88C]/30">
        <Checkbox
          id="firewood"
          checked={formData.addOns.firewood}
          onCheckedChange={(checked) => handleAddOnChange("firewood", checked as boolean)}
          className="border-2 border-[#3C2317] data-[state=checked]:bg-[#3C2317] data-[state=checked]:border-[#3C2317] h-5 w-5 mt-1 flex-shrink-0"
        />
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start mb-1">
            <Label htmlFor="firewood" className="text-[#3C2317] font-medium text-base cursor-pointer">
              Premium Firewood
            </Label>
            <span className="text-[#3C2317] font-bold text-base whitespace-nowrap ml-3">
              AED {settings?.addOnPrices?.firewood || 75}
            </span>
          </div>
          <p className="text-sm text-[#3C2317]/80 mt-1">Seasoned wood for cozy campfires</p>
        </div>
      </div>

      {/* Portable Toilet Add-on */}
      <div className="flex items-start space-x-4 p-4 rounded-xl hover:bg-[#E6CFA9]/50 transition-all duration-300 border border-transparent hover:border-[#D3B88C]/30">
        <Checkbox
          id="portableToilet"
          checked={formData.addOns.portableToilet}
          onCheckedChange={(checked) => handleAddOnChange("portableToilet", checked as boolean)}
          className="border-2 border-[#3C2317] data-[state=checked]:bg-[#3C2317] data-[state=checked]:border-[#3C2317] h-5 w-5 mt-1 flex-shrink-0"
        />
        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start mb-1">
            <Label htmlFor="portableToilet" className="text-[#3C2317] font-medium text-base cursor-pointer">
              Luxury Portable Toilet
            </Label>
            <span className="text-[#3C2317] font-bold text-base whitespace-nowrap ml-3">
              {formData.hasChildren
                ? "FREE with children"
                : `AED ${settings?.addOnPrices?.portableToilet || 200}`}
            </span>
          </div>
          <p className="text-sm text-[#3C2317]/80 mt-1">Private, clean facilities for your comfort</p>
        </div>
      </div>

      {/* Children Option */}
      <div className="flex items-start space-x-4 p-4 rounded-xl hover:bg-[#E6CFA9]/50 transition-all duration-300 border border-transparent hover:border-[#D3B88C]/30">
        <Checkbox
          id="hasChildren"
          checked={formData.hasChildren}
          onCheckedChange={(checked) => handleInputChange("hasChildren", checked as boolean)}
          className="border-2 border-[#3C2317] data-[state=checked]:bg-[#3C2317] data-[state=checked]:border-[#3C2317] h-5 w-5 mt-1 flex-shrink-0"
        />
        <div className="flex-1 min-w-0">
          <Label htmlFor="hasChildren" className="text-[#3C2317] font-medium text-base cursor-pointer block mb-1">
            Children in group
          </Label>
          <p className="text-sm text-[#3C2317]/80">Makes portable toilet complimentary</p>
        </div>
      </div>
    </div>
  </CardContent>
</Card>

              {settings?.customAddOns && settings.customAddOns.length > 0 && (
  <Card className="border-[#D3B88C]/50 shadow-xl hover:shadow-2xl transition-all duration-300 bg-[#FBF9D9]/80 backdrop-blur-sm !py-0">
    <CardHeader className="bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 border-b border-[#D3B88C]/50 h-14 py-4">
      <CardTitle className="text-[#3C2317] flex items-center justify-between text-xl">
        Exclusive Services
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onClick={handleManualRefresh}
          disabled={loadingSettings}
          className="text-[#3C2317] hover:text-[#3C2317]/80 hover:bg-[#3C2317]/10"
        >
          {loadingSettings ? <Loader2 className="w-4 h-4 animate-spin" /> : "Refresh"}
        </Button>
      </CardTitle>
    </CardHeader>
    <CardContent className="p-6 space-y-3">
      {settings.customAddOns.map((addon) => (
        <div
          key={addon.id}
          className="flex items-start space-x-4 p-4 rounded-xl hover:bg-[#E6CFA9]/50 transition-all duration-300 border border-transparent hover:border-[#D3B88C]/30"
        >
          <Checkbox
            id={`custom-${addon.id}`}
            checked={selectedCustomAddOns.includes(addon.id)}
            onCheckedChange={(checked) => handleCustomAddOnChange(addon.id, checked as boolean)}
            className="border-2 border-[#3C2317] data-[state=checked]:bg-[#3C2317] data-[state=checked]:border-[#3C2317] h-5 w-5 mt-1 flex-shrink-0"
          />
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-start mb-1">
              <Label htmlFor={`custom-${addon.id}`} className="text-[#3C2317] font-medium text-base cursor-pointer">
                {addon.name}
              </Label>
              <span className="text-[#3C2317] font-bold text-base whitespace-nowrap ml-3">
                AED {addon.price}
              </span>
            </div>
            {addon.description && (
              <p className="text-sm text-[#3C2317]/80 mt-1">{addon.description}</p>
            )}
          </div>
        </div>
      ))}
    </CardContent>
  </Card>
)}

              <Card className="border-[#D3B88C]/50 shadow-xl hover:shadow-2xl transition-all duration-300 bg-[#FBF9D9]/80 backdrop-blur-sm !py-0">
                <CardHeader className="bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 border-b border-[#D3B88C]/50 h-14 py-4">
                  <CardTitle className="text-[#3C2317] text-xl">Special Requests</CardTitle>
                </CardHeader>
                <CardContent className="p-8">
                  <Label htmlFor="notes" className="text-[#3C2317] mb-3 block font-medium">
                    Additional Notes
                  </Label>
                  <Textarea
                    id="notes"
                    placeholder="Any special requests, dietary requirements, or celebration details..."
                    value={formData.notes}
                    onChange={(e) => handleInputChange("notes", e.target.value)}
                    rows={4}
                    className="border-2 border-[#D3B88C] focus:border-[#3C2317] focus:ring-2 focus:ring-[#3C2317]/20 transition-all duration-300 rounded-xl resize-none"
                  />
                </CardContent>
              </Card>

              <div className="grid md:grid-cols-2 gap-8">
                <Card className="border-[#D3B88C]/50 shadow-xl bg-gradient-to-br from-[#FBF9D9] to-[#E6CFA9] !py-0">
                  <CardHeader className="bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 border-b border-[#D3B88C] h-14 py-4">
                    <CardTitle className="text-[#3C2317] flex items-center text-xl">
                      <Check className="w-6 h-6 mr-3" />
                      Premium Inclusions
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-8">
                    <ul className="space-y-3 text-[#3C2317]">
                      <li className="flex items-start space-x-3">
                        <Check className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Luxury tent setup for up to 4 persons</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Premium bedding & sleeping pillows</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Winter bedding set & blankets</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Professional fire pit setup</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Safety equipment & fire extinguisher</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Comfortable foldable furniture</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Complete cooking equipment & utensils</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <Check className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Ambient lighting & power solutions</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="border-[#D3B88C]/50 shadow-xl bg-gradient-to-br from-[#FBF9D9] to-[#E6CFA9] !py-0">
                  <CardHeader className="bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 border-b border-[#D3B88C] h-14 py-4">
                    <CardTitle className="text-[#3C2317] flex items-center text-xl">
                      <X className="w-6 h-6 mr-3" />
                      Not Included
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-8">
                    <ul className="space-y-3 text-[#3C2317]">
                      <li className="flex items-start space-x-3">
                        <X className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Food & beverages (bring your favorites)</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <X className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Fuel & charcoal (available as add-ons)</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <X className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Personal toiletries & towels</span>
                      </li>
                      <li className="flex items-start space-x-3">
                        <X className="w-5 h-5 mt-0.5 text-[#3C2317]" />
                        <span>Transportation to location</span>
                      </li>
                    </ul>
                    <div className="mt-6 p-4 bg-[#E6CFA9] rounded-xl">
                      <p className="text-sm text-[#3C2317] font-medium">
                        💡 Pro Tip: We welcome you to bring your own food and drinks for a personalized experience!
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="border-[#D3B88C]/50 shadow-xl bg-[#FBF9D9]/80 backdrop-blur-sm !py-0">
                <CardHeader className="bg-gradient-to-r from-[#D3B88C]/20 to-[#E6CFA9]/20 border-b border-[#D3B88C]/50 h-14 py-4">
                  <CardTitle className="text-[#3C2317] text-xl">Important Information</CardTitle>
                </CardHeader>
                <CardContent className="p-8 space-y-6 text-[#3C2317]">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-bold mb-3 text-[#3C2317]">📍 Location & Access</h4>
                        <p className="text-[#3C2317]/80 leading-relaxed">
                          Our premium locations require 4x4 access. We provide secure parking and guided transport to
                          your camping site for the ultimate adventure experience.
                        </p>
                      </div>

                      <div>
                        <h4 className="font-bold mb-3 text-[#3C2317]">🎯 Meeting Point</h4>
                        <p className="text-[#3C2317]/80 leading-relaxed">
                          Detailed meeting point and timing will be sent via email after booking confirmation. Our
                          professional guides will escort you to your luxury setup.
                        </p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <h4 className="font-bold mb-3 text-[#3C2317]">👕 What to Bring</h4>
                        <p className="text-[#3C2317]/80 leading-relaxed">
                          Warm clothing for evening temperatures, comfortable footwear, and personal items. Desert
                          nights can be surprisingly cool!
                        </p>
                      </div>

                      <div>
                        <h4 className="font-bold mb-3 text-[#3C2317]">🐕 Pet Policy</h4>
                        <p className="text-[#3C2317]/80 leading-relaxed">
                          Well-behaved pets are welcome! Please bring their food and ensure they won't disturb the
                          peaceful camping atmosphere.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </form>
          </div>

          <div className="lg:col-span-1">
            <Card className="sticky top-24 border-[#D3B88C]/50 shadow-2xl bg-[#FBF9D9]/90 backdrop-blur-md overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-[#3C2317] to-[#5D4037] text-[#FBF9D9] p-8">
                <CardTitle className="text-2xl font-bold">Booking Summary</CardTitle>
                <p className="text-[#FBF9D9]/90">Your luxury camping experience</p>
              </CardHeader>
              <CardContent className="p-8 space-y-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-[#E6CFA9]/30 rounded-xl">
                    <span className="text-[#3C2317] font-medium">
                      {formData.numberOfTents} Tent{formData.numberOfTents > 1 ? "s" : ""} ({formData.location})
                    </span>
                    <span className="font-bold text-[#3C2317]">AED {pricing.tentPrice.toFixed(2)}</span>
                  </div>

                  {formData.location === "Wadi" && (
                    <div className="flex justify-between text-sm p-3 bg-[#E6CFA9]/20 rounded-lg">
                      <span className="text-[#3C2317]/80">Wadi Premium Surcharge</span>
                      <span className="text-[#3C2317] font-medium">
                        AED {pricing.locationSurcharge.toFixed(2)}
                      </span>
                    </div>
                  )}

                  {pricing.addOnsCost > 0 && (
                    <div className="flex justify-between text-sm p-3 bg-[#E6CFA9]/20 rounded-lg">
                      <span className="text-[#3C2317]/80">Premium Add-ons</span>
                      <span className="text-[#3C2317] font-medium">AED {pricing.addOnsCost.toFixed(2)}</span>
                    </div>
                  )}

                  {pricing.customAddOnsCost > 0 && (
                    <div className="flex justify-between text-sm p-3 bg-[#E6CFA9]/20 rounded-lg">
                      <span className="text-[#3C2317]/80">Exclusive Services</span>
                      <span className="text-[#3C2317] font-medium">
                        AED {pricing.customAddOnsCost.toFixed(2)}
                      </span>
                    </div>
                  )}

                  <div className="border-t border-[#D3B88C] pt-4 space-y-3">
                    <div className="flex justify-between">
                      <span className="text-[#3C2317] font-medium">Subtotal</span>
                      <span className="text-[#3C2317] font-bold">AED {pricing.subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-[#3C2317]/80">
                        VAT ({((settings?.vatRate || 0.05) * 100).toFixed(0)}%)
                      </span>
                      <span className="text-[#3C2317] font-medium">AED {pricing.vat.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="border-t-2 border-[#3C2317]/20 pt-4">
                    <div className="flex justify-between text-2xl font-bold p-4 bg-gradient-to-r from-[#3C2317]/10 to-[#5D4037]/10 rounded-xl">
                      <span className="text-[#3C2317]">Total</span>
                      <span className="text-[#3C2317]">AED {pricing.total.toFixed(2)}</span>
                    </div>
                  </div>

                  <Button
                    onClick={handleSubmit}
                    type="submit"
                    className="w-full bg-gradient-to-r from-[#3C2317] to-[#5D4037] hover:from-[#3C2317]/90 hover:to-[#5D4037]/90 text-[#FBF9D9] font-bold py-4 text-lg shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer"
                    size="lg"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <div className="flex items-center space-x-3">
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>Processing...</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-3">
                        <Shield className="w-5 h-5" />
                        <span>Reserve Your Adventure</span>
                      </div>
                    )}
                  </Button>
                </div>

                <div className="text-center">
                  <p className="text-xs text-[#3C2317]/80 mb-4">
                    🔒 Secure payment powered by Stripe. You will be redirected to complete your payment safely.
                  </p>
                </div>

                <div className="bg-gradient-to-r from-[#E6CFA9]/50 to-[#D3B88C]/20 p-6 rounded-xl border border-[#3C2317]/10">
                  <h4 className="font-bold text-[#3C2317] mb-4 text-lg">💰 Pricing Guide</h4>
                  <ul className="text-sm text-[#3C2317]/80 space-y-2">
                    <li className="flex justify-between">
                      <span>Single tent:</span>
                      <span className="font-medium">AED {settings?.tentPrices?.singleTent || 1497} + VAT</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Multiple tents:</span>
                      <span className="font-medium">AED {settings?.tentPrices?.multipleTents || 1297} each + VAT</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Wadi surcharge:</span>
                      <span className="font-medium">AED {settings?.wadiSurcharge || 250}</span>
                    </li>
                    <li className="flex justify-between text-[#3C2317]">
                      <span>Children bonus:</span>
                      <span className="font-medium">FREE portable toilet</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
