//@ts-nocheck
"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Search, Eye, Trash2, Calendar, MapPin, Users, DollarSign, Tent, AlertCircle } from "lucide-react"
import { toast } from "sonner"
import type { Booking } from "@/lib/types"

export default function OrdersPage() {
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [locationFilter, setLocationFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null)
  const [deleteLoading, setDeleteLoading] = useState<string | null>(null)

  useEffect(() => {
    fetchBookings()
  }, [searchTerm, locationFilter, statusFilter])

  const fetchBookings = async () => {
    try {
      const params = new URLSearchParams()
      if (searchTerm) params.append("search", searchTerm)
      if (locationFilter !== "all") params.append("location", locationFilter)
      if (statusFilter !== "all") params.append("isPaid", statusFilter)

      const response = await fetch(`/api/bookings?${params}`)
      const data = await response.json()
      setBookings(data.bookings || [])
    } catch (error) {
      console.error("Error fetching bookings:", error)
      toast.error("Failed to fetch bookings")
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteBooking = async (bookingId: string) => {
    setDeleteLoading(bookingId)
    try {
      const response = await fetch(`/api/bookings/${bookingId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        setBookings(bookings.filter((booking) => booking._id !== bookingId))
        toast.success("Booking deleted successfully")
      } else {
        toast.error("Failed to delete booking")
      }
    } catch (error) {
      console.error("Error deleting booking:", error)
      toast.error("Failed to delete booking")
    } finally {
      setDeleteLoading(null)
    }
  }

  const handleStatusUpdate = async (bookingId: string, newStatus: boolean) => {
    try {
      const response = await fetch(`/api/bookings/${bookingId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isPaid: newStatus }),
      })

      if (response.ok) {
        setBookings(
          bookings.map((booking) => (booking._id === bookingId ? { ...booking, isPaid: newStatus } : booking)),
        )
        toast.success(`Status updated to ${newStatus ? "Paid" : "Pending"}`)
      } else {
        toast.error("Failed to update status")
      }
    } catch (error) {
      console.error("Error updating status:", error)
      toast.error("Failed to update status")
    }
  }

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const getStatusBadge = (booking: Booking) => {
    if (booking.isPaid) {
      return (
        <Badge
          className="bg-green-100 text-green-800 border-green-200 cursor-pointer hover:bg-green-600 hover:text-white transition-all duration-200 font-medium"
          onClick={() => handleStatusUpdate(booking._id, false)}
          title="Click to mark as Pending"
        >
          Paid
        </Badge>
      )
    }
    return (
      <Badge
        className="bg-amber-100 text-amber-800 border-amber-200 cursor-pointer hover:bg-amber-600 hover:text-white transition-all duration-200 font-medium"
        onClick={() => handleStatusUpdate(booking._id, true)}
        title="Click to mark as Paid"
      >
        Pending
      </Badge>
    )
  }

  return (
    <div className="min-h-screen">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#3C2317] to-[#5D4037] rounded-xl flex items-center justify-center mr-4 shadow-lg">
              <Tent className="w-6 h-6 text-[#FBF9D9]" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-[#3C2317]">Orders Management</h1>
              <p className="text-[#3C2317]/80 text-base mt-1">
                Manage all booking orders with detailed view and actions
              </p>
            </div>
          </div>
        </div>

        {/* Filters */}
        <Card className="bg-[#FBF9D9]/80 backdrop-blur-sm border-[#D3B88C]/50 shadow-xl mb-6">
          <CardHeader className="border-b border-[#D3B88C]/50">
            <CardTitle className="text-[#3C2317] text-lg font-semibold flex items-center">
              <Search className="w-5 h-5 mr-2 text-[#D3B88C]" />
              Search & Filter Orders
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-[#3C2317]/60" />
                  <Input
                    placeholder="Search by name, email, or phone..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 border-[#D3B88C] focus:border-[#3C2317] focus:ring-[#3C2317]/20 bg-white/50"
                  />
                </div>
              </div>

              <Select value={locationFilter} onValueChange={setLocationFilter}>
                <SelectTrigger className="w-full md:w-48 border-[#D3B88C] focus:border-[#3C2317] bg-white/50">
                  <SelectValue placeholder="All Locations" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  <SelectItem value="Desert">Desert</SelectItem>
                  <SelectItem value="Mountain">Mountain</SelectItem>
                  <SelectItem value="Wadi">Wadi</SelectItem>
                  <SelectItem value="Private Events">Private Events</SelectItem>
                </SelectContent>
              </Select>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-48 border-[#D3B88C] focus:border-[#3C2317] bg-white/50">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="true">Paid</SelectItem>
                  <SelectItem value="false">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Orders Table */}
        <Card className="bg-[#FBF9D9]/80 backdrop-blur-sm border-[#D3B88C]/50 shadow-xl">
          <CardContent className="p-0">
            {loading ? (
              <div className="flex items-center justify-center p-8">
                <div className="relative">
                  <div className="w-8 h-8 border-4 border-[#3C2317]/20 rounded-full animate-spin">
                    <div className="absolute inset-0 w-8 h-8 border-4 border-t-[#3C2317] rounded-full animate-spin"></div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-[#D3B88C]/50 bg-gradient-to-r from-[#3C2317] to-[#5D4037] hover:from-[#3C2317] hover:to-[#5D4037]">
                      <TableHead className="text-[#FBF9D9] font-bold text-sm">Order ID</TableHead>
                      <TableHead className="text-[#FBF9D9] font-bold text-sm">Customer</TableHead>
                      <TableHead className="text-[#FBF9D9] font-bold text-sm hidden sm:table-cell">Date</TableHead>
                      <TableHead className="text-[#FBF9D9] font-bold text-sm hidden md:table-cell">Location</TableHead>
                      <TableHead className="text-[#FBF9D9] font-bold text-sm hidden lg:table-cell">Tents</TableHead>
                      <TableHead className="text-[#FBF9D9] font-bold text-sm">Total</TableHead>
                      <TableHead className="text-[#FBF9D9] font-bold text-sm">Status</TableHead>
                      <TableHead className="text-[#FBF9D9] font-bold text-sm">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bookings.map((booking, index) => (
                      <TableRow
                        key={booking._id}
                        className={`border-[#D3B88C]/30 hover:bg-[#3C2317]/10 transition-all duration-200 cursor-default ${
                          index % 2 === 0 ? "bg-white/50" : "bg-[#E6CFA9]/20"
                        }`}
                      >
                        <TableCell className="font-mono text-sm text-[#3C2317] font-medium">
                          #{booking._id.slice(-6).toUpperCase()}
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium text-[#3C2317] text-sm">{booking.customerName}</div>
                            <div className="text-xs text-[#3C2317]/60 hidden sm:block">{booking.customerEmail}</div>
                            <div className="text-xs text-[#3C2317]/60 sm:hidden">{booking.customerPhone}</div>
                          </div>
                        </TableCell>
                        <TableCell className="text-[#3C2317] hidden sm:table-cell text-sm">
                          <div className="flex items-center">
                            <Calendar className="w-3 h-3 mr-1 text-[#D3B88C]" />
                            {formatDate(booking.bookingDate)}
                          </div>
                        </TableCell>
                        <TableCell className="text-[#3C2317] hidden md:table-cell text-sm">
                          <div className="flex items-center">
                            <MapPin className="w-3 h-3 mr-1 text-[#D3B88C]" />
                            {booking.location}
                          </div>
                        </TableCell>
                        <TableCell className="text-[#3C2317] hidden lg:table-cell text-sm">
                          <div className="flex items-center">
                            <Users className="w-3 h-3 mr-1 text-[#D3B88C]" />
                            {booking.numberOfTents}
                          </div>
                        </TableCell>
                        <TableCell className="font-medium text-[#0891b2] text-sm">
                          <div className="flex items-center">
                            <DollarSign className="w-3 h-3 mr-1" />
                            AED {booking.total.toFixed(2)}
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(booking)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            {/* View Detail Dialog */}
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => setSelectedBooking(booking)}
                                  className="border-[#D3B88C] text-[#3C2317] hover:bg-[#3C2317] hover:text-white hover:border-[#3C2317] cursor-pointer transition-all duration-200 h-8 px-2"
                                >
                                  <Eye className="w-3 h-3" />
                                  <span className="hidden sm:inline ml-1 text-xs">View</span>
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-4xl max-h-[85vh] overflow-y-auto bg-gradient-to-br from-[#FBF9D9] to-[#E6CFA9] backdrop-blur-sm border-2 border-[#D3B88C] shadow-2xl">
                                <DialogHeader className="border-b border-[#D3B88C]/50 pb-4">
                                  <DialogTitle className="text-[#3C2317] text-2xl font-bold flex items-center">
                                    <Tent className="w-6 h-6 mr-3 text-[#D3B88C]" />
                                    Order Details - #{selectedBooking?._id.slice(-6).toUpperCase()}
                                  </DialogTitle>
                                </DialogHeader>
                                {selectedBooking && (
                                  <div className="space-y-6 pt-4">
                                    <div className="grid md:grid-cols-2 gap-6">
                                      <div className="space-y-4">
                                        <div className="bg-white/60 backdrop-blur-sm rounded-lg p-4 border border-[#D3B88C]/30">
                                          <h4 className="font-semibold mb-3 text-[#3C2317] border-b border-[#D3B88C]/50 pb-2 flex items-center">
                                            <Users className="w-4 h-4 mr-2 text-[#D3B88C]" />
                                            Customer Information
                                          </h4>
                                          <div className="space-y-3 text-sm">
                                            <div className="flex justify-between items-center">
                                              <span className="text-[#3C2317]/70 font-medium">Name:</span>
                                              <span className="font-semibold text-[#3C2317]">
                                                {selectedBooking.customerName}
                                              </span>
                                            </div>
                                            <div className="flex justify-between items-center">
                                              <span className="text-[#3C2317]/70 font-medium">Email:</span>
                                              <span className="font-semibold text-[#3C2317] text-xs">
                                                {selectedBooking.customerEmail}
                                              </span>
                                            </div>
                                            <div className="flex justify-between items-center">
                                              <span className="text-[#3C2317]/70 font-medium">Phone:</span>
                                              <span className="font-semibold text-[#3C2317]">
                                                {selectedBooking.customerPhone}
                                              </span>
                                            </div>
                                          </div>
                                        </div>
                                      </div>

                                      <div className="space-y-4">
                                        <div className="bg-white/60 backdrop-blur-sm rounded-lg p-4 border border-[#D3B88C]/30">
                                          <h4 className="font-semibold mb-3 text-[#3C2317] border-b border-[#D3B88C]/50 pb-2 flex items-center">
                                            <Calendar className="w-4 h-4 mr-2 text-[#D3B88C]" />
                                            Booking Details
                                          </h4>
                                          <div className="space-y-3 text-sm">
                                            <div className="flex justify-between items-center">
                                              <span className="text-[#3C2317]/70 font-medium">Date:</span>
                                              <span className="font-semibold text-[#3C2317]">
                                                {formatDate(selectedBooking.bookingDate)}
                                              </span>
                                            </div>
                                            <div className="flex justify-between items-center">
                                              <span className="text-[#3C2317]/70 font-medium">Location:</span>
                                              <span className="font-semibold text-[#3C2317]">
                                                {selectedBooking.location}
                                              </span>
                                            </div>
                                            <div className="flex justify-between items-center">
                                              <span className="text-[#3C2317]/70 font-medium">Tents:</span>
                                              <span className="font-semibold text-[#3C2317]">
                                                {selectedBooking.numberOfTents}
                                              </span>
                                            </div>
                                            <div className="flex justify-between items-center">
                                              <span className="text-[#3C2317]/70 font-medium">Children:</span>
                                              <span className="font-semibold text-[#3C2317]">
                                                {selectedBooking.hasChildren ? "Yes" : "No"}
                                              </span>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>

                                    {/* Standard Add-ons */}
                                    {(selectedBooking.addOns.charcoal ||
                                      selectedBooking.addOns.firewood ||
                                      selectedBooking.addOns.portableToilet) && (
                                      <div>
                                        <h4 className="font-medium mb-3 text-[#3C2317] border-b border-[#D3B88C]/50 pb-2">
                                          Standard Add-ons
                                        </h4>
                                        <div className="grid grid-cols-2 gap-2 text-sm">
                                          {selectedBooking.addOns.charcoal && (
                                            <div className="flex items-center text-[#3C2317]">
                                              <div className="w-2 h-2 bg-[#D3B88C] rounded-full mr-2"></div>
                                              Charcoal
                                            </div>
                                          )}
                                          {selectedBooking.addOns.firewood && (
                                            <div className="flex items-center text-[#3C2317]">
                                              <div className="w-2 h-2 bg-[#D3B88C] rounded-full mr-2"></div>
                                              Firewood
                                            </div>
                                          )}
                                          {selectedBooking.addOns.portableToilet && (
                                            <div className="flex items-center text-[#3C2317]">
                                              <div className="w-2 h-2 bg-[#D3B88C] rounded-full mr-2"></div>
                                              Portable Toilet
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    )}

                                    {selectedBooking.selectedCustomAddOns &&
                                      selectedBooking.selectedCustomAddOns.length > 0 && (
                                        <div>
                                          <h4 className="font-medium mb-3 text-[#3C2317] border-b border-[#D3B88C]/50 pb-2">
                                            Additional Services
                                          </h4>
                                          <div className="grid grid-cols-2 gap-2 text-sm">
                                            {selectedBooking.selectedCustomAddOns.map((addOnId: string) => (
                                              <div key={addOnId} className="flex items-center text-[#3C2317]">
                                                <div className="w-2 h-2 bg-[#84cc16] rounded-full mr-2"></div>
                                                Custom Service #{addOnId.slice(-4)}
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      )}

                                    {selectedBooking.notes && (
                                      <div>
                                        <h4 className="font-medium mb-3 text-[#3C2317] border-b border-[#D3B88C]/50 pb-2">
                                          Special Notes
                                        </h4>
                                        <p className="text-sm text-[#3C2317] bg-[#E6CFA9]/30 p-3 rounded-lg">
                                          {selectedBooking.notes}
                                        </p>
                                      </div>
                                    )}

                                    <div className="bg-white/60 backdrop-blur-sm rounded-lg p-4 border border-[#D3B88C]/30">
                                      <h4 className="font-semibold mb-3 text-[#3C2317] border-b border-[#D3B88C]/50 pb-2 flex items-center">
                                        <DollarSign className="w-4 h-4 mr-2 text-[#D3B88C]" />
                                        Payment Summary
                                      </h4>
                                      <div className="space-y-3 text-sm">
                                        <div className="flex justify-between items-center">
                                          <span className="text-[#3C2317]/70 font-medium">Subtotal:</span>
                                          <span className="font-semibold text-[#3C2317]">
                                            AED {selectedBooking.subtotal.toFixed(2)}
                                          </span>
                                        </div>
                                        <div className="flex justify-between items-center">
                                          <span className="text-[#3C2317]/70 font-medium">VAT (5%):</span>
                                          <span className="font-semibold text-[#3C2317]">
                                            AED {selectedBooking.vat.toFixed(2)}
                                          </span>
                                        </div>
                                        <div className="flex justify-between items-center border-t border-[#D3B88C]/50 pt-3">
                                          <span className="font-bold text-[#3C2317] text-base">Total:</span>
                                          <span className="font-bold text-[#0891b2] text-lg">
                                            AED {selectedBooking.total.toFixed(2)}
                                          </span>
                                        </div>
                                        <div className="flex justify-between items-center">
                                          <span className="text-[#3C2317]/70 font-medium">Status:</span>
                                          <span>{getStatusBadge(selectedBooking)}</span>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </DialogContent>
                            </Dialog>

                            {/* Delete Action */}
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="border-red-200 text-red-600 hover:bg-red-600 hover:text-white hover:border-red-600 cursor-pointer transition-all duration-200 h-8 px-2 bg-transparent"
                                  disabled={deleteLoading === booking._id}
                                >
                                  {deleteLoading === booking._id ? (
                                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-red-600"></div>
                                  ) : (
                                    <Trash2 className="w-3 h-3" />
                                  )}
                                  <span className="hidden sm:inline ml-1 text-xs">Delete</span>
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent className="bg-gradient-to-br from-[#FBF9D9] to-[#E6CFA9] backdrop-blur-sm border-2 border-red-200 shadow-2xl">
                                <AlertDialogHeader>
                                  <AlertDialogTitle className="text-red-600 text-xl font-bold flex items-center">
                                    <AlertCircle className="w-5 h-5 mr-2" />
                                    Delete Order
                                  </AlertDialogTitle>
                                  <AlertDialogDescription className="text-[#3C2317] text-base leading-relaxed">
                                    Are you sure you want to delete this order? This action cannot be undone.
                                    <div className="mt-4 p-3 bg-red-50 rounded-lg border border-red-200">
                                      <div className="text-sm space-y-1">
                                        <div>
                                          <strong>Order:</strong> #{booking._id.slice(-6).toUpperCase()}
                                        </div>
                                        <div>
                                          <strong>Customer:</strong> {booking.customerName}
                                        </div>
                                        <div>
                                          <strong>Total:</strong> AED {booking.total.toFixed(2)}
                                        </div>
                                      </div>
                                    </div>
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel className="border-[#D3B88C] text-[#3C2317] hover:bg-[#D3B88C]/20 cursor-pointer">
                                    Cancel
                                  </AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleDeleteBooking(booking._id)}
                                    className="bg-red-600 hover:bg-red-700 cursor-pointer transition-colors"
                                  >
                                    Delete Order
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}

            {!loading && bookings.length === 0 && (
              <div className="text-center py-12">
                <div className="text-[#3C2317]/60 mb-4">
                  <Search className="w-12 h-12 mx-auto" />
                </div>
                <h3 className="text-lg font-medium text-[#3C2317] mb-2">No orders found</h3>
                <p className="text-[#3C2317]/60">Try adjusting your search criteria or filters.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
