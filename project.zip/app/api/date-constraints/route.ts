import { type NextRequest, NextResponse } from "next/server"

const dateLocationLocks: { [date: string]: { lockedLocation: string; totalTents: number } } = {}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const date = searchParams.get("date")

    if (!date) {
      return NextResponse.json({ error: "Date parameter is required" }, { status: 400 })
    }

    const existingLock = dateLocationLocks[date]

    if (existingLock) {
      return NextResponse.json({
        lockedLocation: existingLock.lockedLocation,
        totalTents: existingLock.totalTents,
      })
    }

    // No existing lock found
    return NextResponse.json({
      lockedLocation: null,
      totalTents: 0,
    })
  } catch (error) {
    console.error("Error checking date constraints:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { date, location, tents } = await request.json()

    if (!date || !location || !tents) {
      return NextResponse.json({ error: "Date, location, and tents are required" }, { status: 400 })
    }

    if (dateLocationLocks[date]) {
      dateLocationLocks[date].totalTents += tents
    } else {
      dateLocationLocks[date] = {
        lockedLocation: location,
        totalTents: tents,
      }
    }

    return NextResponse.json({
      success: true,
      lockedLocation: dateLocationLocks[date].lockedLocation,
      totalTents: dateLocationLocks[date].totalTents,
    })
  } catch (error) {
    console.error("Error updating date constraints:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
