import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Get bookings from the in-memory storage
    const bookingsResponse = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/api/bookings`)
    const bookingsData = await bookingsResponse.json()
    const bookings = bookingsData.bookings || []

    // Calculate stats
    const totalBookings = bookings.length
    const paidBookings = bookings.filter((b: any) => b.status === "paid").length
    const totalRevenue = bookings
      .filter((b: any) => b.status === "paid")
      .reduce((sum: number, b: any) => sum + (b.total || 0), 0)
    const pendingBookings = totalBookings - paidBookings

    const stats = {
      totalBookings,
      paidBookings,
      totalRevenue,
      pendingBookings,
    }

    return NextResponse.json(stats, {
      headers: {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        Pragma: "no-cache",
        Expires: "0",
      },
    })
  } catch (error) {
    console.error("Error fetching stats:", error)
    return NextResponse.json(
      {
        totalBookings: 0,
        paidBookings: 0,
        totalRevenue: 0,
        pendingBookings: 0,
      },
      { status: 200 },
    )
  }
}
